<div class="newsups">                   
    <textarea id="editnewstext" rows="2" cols="50">{{ $n->news}} </textarea>
</div>

<div><button id="edit" type="button" onclick="editpost({{$n->newsfeed_id}})">Edit</button></div>