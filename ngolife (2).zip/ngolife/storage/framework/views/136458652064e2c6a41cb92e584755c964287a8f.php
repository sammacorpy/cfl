<?php $__env->startSection('wavecolor','#606060'); ?>
<?php $__env->startSection('title','News'); ?>

<?php $__env->startSection('stylesheet'); ?>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/profile.css">
    <link rel="stylesheet" href="/css/news.css">
    
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nixie+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Gentium+Book+Basic" rel="stylesheet">   

    <script>
        var d;

        function dispshow(d) {
            d = ".menuitems" + d;
            $(d).toggleClass('show');
   
        }
        function dispout(d){
            d = ".menuitems" + d;
            $(d).removeClass('show');
        }
    </script>  
    <script src="/js/newsmenu.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navitems'); ?>
    <?php if(!isset($_SESSION['usrname'])): ?>
        <form class="navbar-form navbar-right" role="search" action="/signin" method="post">
        <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="Username">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
            <button type="submit" class="btncustom custombutton" style="background-color:orange;">Sign In</button>
        </form>

    <?php else: ?>
        <ul class="nav navbar-nav navbar-right">
            <li class="nav-item" >
                <a href="/profile/<?php echo e($_SESSION['usrname']); ?>" class="underline"><?php echo e($_SESSION['usrname']); ?></a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> 
                    <img src="/storage/profimg/<?php echo e($p); ?>" style="margin-top:-5px;padding:0px;border-radius:100%;" width="30" height="30">
                </a>
                <ul class="dropdown-menu dropdown-cart" role="menu">
                    <li><a href="/profile/e/<?php echo e($_SESSION['usrname']); ?>" style="color:#808080;">Edit Profile</a></li>
                    <li><a href="/changepass/e/<?php echo e($_SESSION['usrname']); ?>" style="color:#808080;">Change Password</a></li>
                    <li><a href="/logout" style="color:#808080;">Logout</a></li>
                </ul>
            </li>
        </ul>   

    <?php endif; ?>

    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

 <?php if(count($errors)>0): ?>
    <div class="jumbotron">
        <div class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($e); ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    

    
    <div class="container">
        <div class="col-md-10 col-md-offset-1 posts">
            <div class="col-md-8 col-md-offset-2">
                <?php if(isset($username)): ?>
                    <div class="blockfpost">
                        <form method="POST" action="/news"  role="form">
                        <?php echo e(csrf_field()); ?>

                            <legend><i class="fa fa-newspaper-o" aria-hidden="true"  style="color:#606060"></i> Post your news</legend>

                            <div class="form-group">
                                <textarea class="form-control" id="news" name="news" placeholder="Hi, <?php echo e($username); ?>! Tell us about your days" rows="5" col="50"></textarea></textarea>
                            </div>  



                    
                            <button type="submit" class="btn btn-primary" id="btn-news">Post</button>
                        </form>
                    </div>
                <?php endif; ?>

                <div class="titlefeed"> News Feed</div>
                <div class="newsfeed">


                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="eachnews" id="eachnews_<?php echo e($n->newsfeed_id); ?>">

                        <div class="username"><span class="profimg"><img src="/storage/profimg/<?php echo e($n->profile_image); ?>" id=""></span><span> <?php echo e($n->username); ?></span>  
                        <?php if(isset($_SESSION['usrname'])): ?>
                        <?php if(strcmp($_SESSION['usrname'],$n->username)==0): ?>
                            <span class="newsmenu">
                                <span class="menuicon"  onclick= "dispshow(<?php echo e($n->newsfeed_id); ?>)" >...
                                <ul class="menuitems<?php echo e($n->newsfeed_id); ?>">
                                    <li onclick="ajaxfuned(<?php echo e($n->newsfeed_id); ?>)"> Edit
                                    </li>
                                    <li onclick="ajaxfundel(<?php echo e($n->newsfeed_id); ?>)" onmouseout="dispout(<?php echo e($n->newsfeed_id); ?>)"> Delete
                                    </li>
                                </ul>
                                </span>
                            </span>
                        <?php endif; ?>
                        <?php endif; ?>
                        <span class="timer"><?php echo e(Carbon\Carbon::parse(DB::table('newsfeeds')->where('newsfeed_id',$n->newsfeed_id)->first()->nf_updated_at)->diffforhumans()); ?></span></div>
                        
                        <div class="newsups" id="newsup_<?php echo e($n->newsfeed_id); ?>">                   
                            <?php echo e($n->news); ?>

                        </div>

                        <div class="lcnav">
                            <div class="like">
                                <i class="fa fa-thumbs-up" aria-hidden="true" onclick="voteup(<?php echo e($n->newsfeed_id); ?>)"> Likes</i>
                            </div>
                            <div class="comment">
                                <i class="fa fa-comments" aria-hidden="true" data-value="<?php echo e($n->newsfeed_id); ?>"> Comments</i>
                            </div>
                        </div>
                        <div class="totallike">
                            <span id="lc<?php echo e($n->newsfeed_id); ?>"><?php echo e($n->votes); ?></span> Likes
                        </div>
                        
                        <div class="commentbox">
                            <div id="totalcomments">
                            </div>
                            <?php if(isset($_SESSION['usrname'])): ?>
                            <span class="profimg cmnt">
                                <img src="/storage/profimg/<?php echo e($p); ?>">
                            </span> 
                            <span>
                                <input id="cmmentinput" type="text" name="comment" placeholder="Write a comment...">
                            </span>
                            <input type="hidden" value="<?php echo e($n->newsfeed_id); ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
                
                    <button type="button" id="viewmore" data-value="1" onclick="viewmore()"><i class="fa fa-caret-down fa-2x" aria-hidden="true"></i></button>
                
            </div>
            
        </div>
        <input id="lp" type="hidden" value="<?php echo e($news->lastpage()); ?>"/>
    </div>
    <script src="/js/profile.js"></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>