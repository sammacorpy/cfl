<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="eachnews" id="eachnews_<?php echo e($n->newsfeed_id); ?>">

                        <div class="username"><span class="profimg"><img src="/storage/profimg/<?php echo e($n->profile_image); ?>" id=""></span><span> <?php echo e($n->username); ?></span>  
                        <?php if(isset($_SESSION['usrname'])): ?>
                        <?php if(strcmp($_SESSION['usrname'],$n->username)==0): ?>
                            <span class="newsmenu">
                                <span class="menuicon"  onclick= "dispshow(<?php echo e($n->newsfeed_id); ?>)" >...
                                <ul class="menuitems<?php echo e($n->newsfeed_id); ?>">
                                    <li onclick="ajaxfuned(<?php echo e($n->newsfeed_id); ?>)"> Edit
                                    </li>
                                    <li onclick="ajaxfundel(<?php echo e($n->newsfeed_id); ?>)" onmouseout="dispout(<?php echo e($n->newsfeed_id); ?>)"> Delete
                                    </li>
                                </ul>
                                </span>
                            </span>
                        <?php endif; ?>
                        <?php endif; ?>
                        <span class="timer"><?php echo e(Carbon\Carbon::parse(DB::table('newsfeeds')->where('newsfeed_id',$n->newsfeed_id)->first()->nf_updated_at)->diffforhumans()); ?></span></div>
                        
                        <div class="newsups" id="newsup_<?php echo e($n->newsfeed_id); ?>">                   
                            <?php echo e($n->news); ?>

                        </div>

                        <div class="lcnav">
                            <div class="like">
                            <i class="fa fa-thumbs-up" aria-hidden="true"></i> <a href="">Likes</a>
                            </div>
                            <div class="comment">
                            <i class="fa fa-comments" aria-hidden="true"></i>  <a href="">Comments</a>
                            </div>
                        </div>
                        <div id="totallike">
                            <span id="likecount">174</span> Likes
                        </div>
                        
                        <div class="commentbox">
                            <div id="totalcomments">
                            </div>
                            <?php if(isset($_SESSION['usrname'])): ?>
                            <span class="profimg cmnt">
                                <img src="/storage/profimg/<?php echo e($p); ?>">
                            </span> 
                            <span>
                                <input id="cmmentinput" type="text" name="comment" placeholder="Write a comment...">
                            </span>
                            <input type="hidden" value="<?php echo e($n->newsfeed_id); ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>