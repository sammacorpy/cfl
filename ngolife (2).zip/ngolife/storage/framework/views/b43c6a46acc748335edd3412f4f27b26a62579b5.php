<div class="newsups">                   
    <textarea id="editnewstext" rows="2" cols="50"><?php echo e($n->news); ?> </textarea>
</div>

<div><button id="edit" type="button" onclick="editpost(<?php echo e($n->newsfeed_id); ?>)">Edit</button></div>