<?php $__env->startSection('title','Profile'); ?>
<?php $__env->startSection('wavecolor','#EB4552'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/profile.css">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
    <script src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="/css/picker.css" />
    <script src="/js/timepicker.js"></script>
    
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nixie+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Gentium+Book+Basic" rel="stylesheet">     

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navitems'); ?>
        <ul class="nav navbar-nav navbar-right">
            <li class="nav-item" >
                <a href="/profile/<?php echo e($username); ?>" class="underline"><?php echo e($_SESSION['usrname']); ?></a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> <img src="/storage/profimg/<?php echo e($p); ?>" style="margin-top:-5px;padding:0px;border-radius:100%;" width="30" height="30"></a>
                <ul class="dropdown-menu dropdown-cart" role="menu">
                    <li><a href="/logout" style="color:#808080;">Logout</a></li>
                </ul>
            </li>
        </ul>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    
    <?php if(count($errors)>0): ?>
    <div class="jumbotron">
        <div class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($e); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    

    <div class="container">

        <div class="row prf" id="abtuser">
            
            
            <div class="col-md-2 rightpart">
                <div>
                    <form enctype="multipart/form-data" method="post" action="/imgupload" id="imageup">
                    <?php echo e(csrf_field()); ?>

                        <img src="/storage/profimg/<?php echo e($p); ?>" class="imgupload" >
                        <div class="changeimg">upload image</div>
                        <input type="file" id="inpfile" class="inpfileupload" name="imgprof">
                        
                    </form>
                </div>
                <div class="nameplate">
                     <?php echo e($username); ?>

                </div>
            </div>
           
            <?php if($permission==1): ?>
            <form method="post" action="/profile/e/<?php echo e($_SESSION['usrname']); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-7 col-md-offset-1 leftpart">
                <div class="data-content">
                
                    <div class="row profdesk">
                        <?php if($job_id=='1' || $job_id=='2'): ?>
                        <b>Name</b>
                        <?php elseif($job_id=='3'): ?>
                        <b>Pharmacy Name</b>
                        <?php else: ?>
                        <b>Hospital Name</b>
                        <?php endif; ?>
                        
                        
                        <?php if($job_id=='1' || $job_id=='2'): ?>
                        <div class="element"><?php echo e($fname.' '.$lname); ?></div>
                        <?php else: ?>
                        <div class="element">
                            <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?>  <?php echo e($userdetails->name); ?> <?php endif; ?>" placeholder="" name="name">
                        </div>
                        <?php endif; ?>

                        <?php if($job_id=='1' || $job_id=='2'): ?>
                        <b>Blood Group</b>
                        <div class="element">
                            <select name="bloodgrp" class="selectelement">
                                <option value="A+" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='A+'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >A+</option>
                                <option value="A-" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='A-'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>A-</option>
                                <option value="B+" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='B+'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>B+</option>
                                <option value="B-" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='B-'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>B-</option>
                                <option value="AB+" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='AB+'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>AB+</option>
                                <option value="AB-" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='AB-'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>AB-</option>
                                <option value="O+" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='O+'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>O+</option>
                                <option value="O-" <?php if(!empty($userdetails)): ?> <?php if($userdetails->bloodgrp=='O-'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>O-</option>
                            </select> 
                        </div>
                        
                            
                        <b>Adhar Number</b>
                        <div class="element">
                            <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->adharno); ?> <?php endif; ?>" placeholder="" name="adharno">
                        </div>
                        <?php endif; ?>
                        <b>Contact <i class="fa fa-mobile" aria-hidden="true"></i></b>
                        <div class="element">
                            <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?>  <?php echo e($userdetails->mobile_no); ?> <?php endif; ?>" placeholder="" name="mobile_no">
                        </div>
                        <?php if($job_id=='1'): ?>
                        <b>Occupation</b>
                        <div class="element">
                            <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->occupation); ?> <?php endif; ?>" placeholder="" name="occupation">
                            
                        </div>
                        <?php endif; ?>
                        <?php if($job_id=='1' || $job_id=='2'): ?>
                        <b>Birth Date</b>
                        <div class="element">
                            <input class="inpelement" type="date" value="<?php if(!empty($userdetails)): ?><?php echo e($userdetails->dob); ?><?php endif; ?>"  name="dob">
                        </div>
                        <?php endif; ?>

                    </div>
                    
                    <div class="row profdesk">
                    <?php if($job_id=='1'): ?>
                        <b>Current Address</b></br><br>
                        <b>country</b>
                        <div class="element">
                            <input type="hidden" id="cscountry" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->curr_country); ?> <?php endif; ?>" name="curr_country">
                        
                            <select class="inpelement" id="ccountry">
                            </select>
            
                        </div>
                        <b>State</b>
                        <div class="element">
                        
                            <input type="hidden" id="csstate" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->curr_state); ?> <?php endif; ?>" name="curr_state">
                            
                            <select class="inpelement" id="cstate"></select>
                        </div>
                        <b>City</b>
                        <div class="element">
                            <input type="hidden" id="cscity" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->curr_city); ?> <?php endif; ?>" name="curr_city">
                        
                            <select class="inpelement" id="ccity"></select> 
                        </div>
                        <b>Street</b>
                        <div class="element">
                            <input class="inpelement" id="cstreet" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->curr_street); ?> <?php endif; ?>" placeholder="" name="curr_street">
                        </div>
                        <b>Zip Code</b>
                        <div class="element">
                            <input class="inpelement" id="czip" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->curr_zip); ?> <?php endif; ?>" placeholder="" name="curr_zip">
                        </div>
                        
                        <br><br>
                        <b>permanent Address</b> <div style="margin-top:10px;"><input type="checkbox" id="smascurr" value="sameascurrent">Same as current Address</div><br><br>
                        <b>country</b>
                        <div class="element">
                            <input type="hidden" id="pscountry" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_country); ?> <?php endif; ?>" name="perm_country">
                        
                        
                            <select class="inpelement" id="pcountry">
                            </select>
            
                        </div>
                        <b>State</b>
                        <div class="element">
                            <input type="hidden" id="psstate" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_state); ?> <?php endif; ?>" name="perm_state">
                        
                        
                            <select class="inpelement" id="pstate"></select>
                        </div>
                        <b>City</b>
                        <div class="element">
                            <input type="hidden" id="pscity" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_city); ?> <?php endif; ?>" name="perm_city">
                        
                            <select class="inpelement" id="pcity"></select> 
                        </div>
                        <b>Street</b>
                        <div class="element">
                            <input class="inpelement" id="pstreet" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_street); ?> <?php endif; ?>" placeholder="" name="perm_street">
                        </div>
                        <b>Zip Code</b>
                        <div class="element">
                            <input class="inpelement" id="pzip" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_zip); ?> <?php endif; ?>" placeholder="" name="perm_zip">
                        </div>
                        
                    <?php elseif($job_id=='2'): ?>
                        <b>Office Address</b></br><br>
                        <b>country</b>
                        <div class="element">
                            <input type="hidden" id="cscountry" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->offi_country); ?> <?php endif; ?>" name="offi_country">
                        
                            <select class="inpelement" id="ccountry">
                            </select>
            
                        </div>
                        <b>State</b>
                        <div class="element">
                        
                            <input type="hidden" id="csstate" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->offi_state); ?> <?php endif; ?>" name="offi_state">
                            
                            <select class="inpelement" id="cstate"></select>
                        </div>
                        <b>City</b>
                        <div class="element">
                            <input type="hidden" id="cscity" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->offi_city); ?> <?php endif; ?>" name="offi_city">
                        
                            <select class="inpelement" id="ccity"></select> 
                        </div>
                        <b>Street</b>
                        <div class="element">
                            <input class="inpelement" id="cstreet" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->offi_street); ?> <?php endif; ?>" placeholder="" name="offi_street">
                        </div>
                        <b>Zip Code</b>
                        <div class="element">
                            <input class="inpelement" id="czip" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->offi_zip); ?> <?php endif; ?>" placeholder="" name="offi_zip">
                        </div>
                        
                        <br><br>
                        <b>permanent Address</b> <div style="margin-top:10px;"><input type="checkbox" id="smascurr" value="sameascurrent">Same as current Address</div><br><br>
                        <b>country</b>
                        <div class="element">
                            <input type="hidden" id="pscountry" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_country); ?> <?php endif; ?>" name="perm_country">
                        
                        
                            <select class="inpelement" id="pcountry">
                            </select>
            
                        </div>
                        <b>State</b>
                        <div class="element">
                            <input type="hidden" id="psstate" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_state); ?> <?php endif; ?>" name="perm_state">
                        
                        
                            <select class="inpelement" id="pstate"></select>
                        </div>
                        <b>City</b>
                        <div class="element">
                            <input type="hidden" id="pscity" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_city); ?> <?php endif; ?>" name="perm_city">
                        
                            <select class="inpelement" id="pcity"></select> 
                        </div>
                        <b>Street</b>
                        <div class="element">
                            <input class="inpelement" id="pstreet" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_street); ?> <?php endif; ?>" placeholder="" name="perm_street">
                        </div>
                        <b>Zip Code</b>
                        <div class="element">
                            <input class="inpelement" id="pzip" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->perm_zip); ?> <?php endif; ?>" placeholder="" name="perm_zip">
                        </div>


















                    <?php else: ?>
                        <b>Location</b></br><br>
                        <b>country</b>
                        <div class="element">
                            <input type="hidden" id="cscountry" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->country); ?> <?php endif; ?>" name="country">
                        
                            <select class="inpelement" id="ccountry">
                            </select>
            
                        </div>
                        <b>State</b>
                        <div class="element">
                        
                            <input type="hidden" id="csstate" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->state); ?> <?php endif; ?>" name="state">
                            
                            <select class="inpelement" id="cstate"></select>
                        </div>
                        <b>City</b>
                        <div class="element">
                            <input type="hidden" id="cscity" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->city); ?> <?php endif; ?>" name="city">
                        
                            <select class="inpelement" id="ccity"></select> 
                        </div>
                        <b>Street</b>
                        <div class="element">
                            <input class="inpelement" id="cstreet" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->street); ?> <?php endif; ?>" placeholder="" name="street">
                        </div>
                        <b>Zip Code</b>
                        <div class="element">
                            <input class="inpelement" id="czip" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->zip); ?> <?php endif; ?>" placeholder="" name="zip">
                        </div>

                    <?php endif; ?>
                    </div>        
                    
                    

                    <?php if($job_id=='1'): ?>
                    <div class="row profdesk">
                       
                        
                        <b>Guardian</b><br><br>
                        <div class="row">
                            <div class="col-md-6">
                                <b>First Name</b>
                                <div class="element">
                                    <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->guardian_f); ?> <?php endif; ?>" placeholder="" name="guardian_f">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <b>Last Name</b>
                                <div class="element">
                                    <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->guardian_l); ?> <?php endif; ?>" placeholder="" name="guardian_l">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <b>Contact <i class="fa fa-mobile" aria-hidden="true"></i></b>
                                <div class="element">
                                    <input class="inpelement" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->guardian_cellno); ?> <?php endif; ?>" placeholder="" name="guardian_cellno">
                                </div>
                            </div>
                        </div>
                        
                    </div> 
                    <?php endif; ?>


                    <?php if($job_id=='2'): ?>
                    <div class="row profdesk">
                        <b>Degrees</b>
                        <div class="element">
                            <input class="inpelement" id="degree" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->education_details); ?> <?php endif; ?>" placeholder="" name="education_details">
                        </div>

                        <b>Specialization</b>
                        <div class="element">
                            <input class="inpelement" id="specs" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->specs); ?> <?php endif; ?>" placeholder="" name="specs">
                        </div>
                        
                        <b>Experience</b>
                        <div class="element">
                            <input class="inpelement" id="exp" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->experience); ?> <?php endif; ?>" placeholder="" name="experience">
                        </div>

                        <b>Works in Hospital</b>
                        <div class="element">
                            <input class="inpelement" id="winhosp" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->worksinhospital); ?> <?php endif; ?>" placeholder="" name="worksinhospital">
                        </div>
                        <b>Availibility Hours</b>
                        <div class="element">
                        From:
                            <input class="inpelement" type="text" id="from" name="availhoursbegin" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursbegin); ?> <?php endif; ?>"/><br>
                        To:
                            <input class="inpelement" type="text" id="to" name="availhoursend" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursend); ?> <?php endif; ?>"/>
                        </div>
                    </div>

                    <?php elseif($job_id=='3'): ?>
                    <div class="row profdesk">
                        <b>Availibility Hours</b>
                        <div class="element">
                        From:
                            <input class="inpelement" type="text" id="from" name="availhoursbegin" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursbegin); ?> <?php endif; ?>"/><br>
                        To:
                            <input class="inpelement" type="text" id="to" name="availhoursend" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursend); ?> <?php endif; ?>"/>
                        </div>                  
                    
                    </div>

                    <?php elseif($job_id=='4'): ?>
                    <div class="row profdesk">
                        <b>Number of doctors</b>
                        <div class="element">
                            <input class="inpelement" id="winhosp" type="text" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->noofdoctors); ?> <?php endif; ?>" placeholder="" name="noofdoctors">
                        </div>

                        <b>Availibility Hours</b>
                        <div class="element">
                        From:
                            <input class="inpelement" type="text" id="from" name="availhoursbegin" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursbegin); ?> <?php endif; ?>"/><br>
                        To:
                            <input class="inpelement" type="text" id="to" name="availhoursend" value="<?php if(!empty($userdetails)): ?> <?php echo e($userdetails->availhoursend); ?> <?php endif; ?>"/>
                        </div>
                    
                    </div>
                    <?php endif; ?>
                </div>

                

                <div class="row deldesk">
                   <input class="btn btn-save" type="submit" value="Save">     
                </div>
            
            </div>
            </form>
        <?php endif; ?>
            
            
            

        </div>

    </div>
    <script>
        $('#from').timepicker({
            
        });
         $('#to').timepicker({
             
         });
    </script>
    <script src="/js/profile.js">
    </script>
    <script src="/js/ajx.js">
    </script>

    <?php
    $_SESSION['job_id']=$job_id;
    ?>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>