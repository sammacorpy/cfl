<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class usersdata extends Model
{
    //
    protected $primaryKey = 'username';
    public $incrementing = false;
}
