<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hospitalfacility extends Model
{
    //
}
